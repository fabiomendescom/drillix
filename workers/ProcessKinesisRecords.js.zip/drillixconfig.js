module.exports = {
  getMongoURI: function () {
	return "mongodb://heroku_app34960699:pbho09fpelbpp597c21fu0cami@ds029197.mongolab.com:29197/heroku_app34960699";
  },
  getMaxReads: function () {
	return 100;
  }
};
